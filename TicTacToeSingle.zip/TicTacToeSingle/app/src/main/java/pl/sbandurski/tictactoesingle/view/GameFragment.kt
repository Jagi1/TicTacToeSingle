package pl.sbandurski.tictactoesingle.view

import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.fragment_game.view.*
import pl.sbandurski.tictactoesingle.R
import pl.sbandurski.tictactoesingle.model.CGame
import pl.sbandurski.tictactoesingle.model.CPlayer
import pl.sbandurski.tictactoesingle.presenter.IMainContract

class GameFragment: Fragment(), IMainContract.IView {

    private lateinit var activity: MainActivity
    private lateinit var presenter: IMainContract.IPresenter
    private lateinit var player1: CPlayer
    private lateinit var player2: CPlayer
    private lateinit var game: CGame
    private lateinit var buttons: ArrayList<Button>
    private lateinit var oldLayout: ConstraintSet
    private var showedMenu = false

    companion object {
        fun newInstance(): GameFragment = GameFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_game, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        oldLayout = ConstraintSet()
        oldLayout.clone(view.fragment_game_layout)
        buttons = arrayListOf(
            view.main_r1_b1, view.main_r1_b2, view.main_r1_b3,
            view.main_r2_b1, view.main_r2_b2, view.main_r2_b3,
            view.main_r3_b1, view.main_r3_b2, view.main_r3_b3
        )
        prepareGame()
        setListeners(view)
    }

    override fun setPresenter(presenter: IMainContract.IPresenter) {
        this.presenter = presenter
    }

    fun setActivity(activity: MainActivity) {
        this.activity = activity
    }

    fun prepareGame() {
        game = CGame()
        player1 = CPlayer("You", "")
        player2 = CPlayer("Enemy", "")
        presenter.initGame(buttons, player1, player2, game)
    }

    fun setListeners(view: View) {
        view.main_iv.setOnClickListener {
            presenter.showMenu(view.main_cl as ConstraintLayout, showedMenu, oldLayout)
            showedMenu = !showedMenu
        }
        view.main_cv_cl_tv1.setOnClickListener {
            presenter.initGame(buttons, player1, player2, game)
        }
        view.main_cv_cl_tv2.setOnClickListener {
            activity.finishAndRemoveTask()
        }
        buttons.forEach { button ->
            button.setOnClickListener { view ->
                presenter.onButtonClicked(
                    view as Button,
                    player1,
                    player2,
                    game,
                    buttons
                )
            }
        }
    }

}