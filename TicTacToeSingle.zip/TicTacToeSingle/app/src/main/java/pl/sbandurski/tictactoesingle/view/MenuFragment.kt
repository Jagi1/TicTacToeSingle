package pl.sbandurski.tictactoesingle.view

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_menu.view.*
import pl.sbandurski.tictactoesingle.R
import pl.sbandurski.tictactoesingle.presenter.IMainContract

class MenuFragment: Fragment(), IMainContract.IView {

    private lateinit var activity: MainActivity
    private lateinit var presenter: IMainContract.IPresenter

    companion object {
        fun newInstance(): MenuFragment = MenuFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_menu, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setListeners(view)
    }

    private fun setListeners(view: View) = with(view) {
        menu_button_1.setOnClickListener {
            activity.setFragment(GameFragment.newInstance())
        }
        menu_button_2.setOnClickListener {

        }
        menu_button_3.setOnClickListener {

        }
    }

    fun setActivity(activity: MainActivity) {
        this.activity = activity
    }

    override fun setPresenter(presenter: IMainContract.IPresenter) {
        this.presenter = presenter
    }
}