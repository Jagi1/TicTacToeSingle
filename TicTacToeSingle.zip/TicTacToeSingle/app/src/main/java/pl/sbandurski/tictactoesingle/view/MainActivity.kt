package pl.sbandurski.tictactoesingle.view

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.support.v4.app.Fragment
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_game.*
import pl.sbandurski.tictactoesingle.R
import pl.sbandurski.tictactoesingle.model.CGame
import pl.sbandurski.tictactoesingle.model.CPlayer
import pl.sbandurski.tictactoesingle.presenter.CMainPresenter
import pl.sbandurski.tictactoesingle.presenter.IMainContract

class MainActivity : AppCompatActivity(), IMainContract.IView {

    private lateinit var presenter: IMainContract.IPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        presenter = CMainPresenter(this)
        val fragment = MenuFragment.newInstance()
        fragment.setPresenter(presenter)
        fragment.setActivity(this)
        setFragment(fragment)
    }

    override fun onDestroy() {
        presenter.onDestroy()
        super.onDestroy()
    }

    fun setFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.fragment, fragment)
        fragmentTransaction.commit()
    }

    override fun setPresenter(presenter: IMainContract.IPresenter) {
        this.presenter = presenter
    }
}