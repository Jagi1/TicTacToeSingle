package pl.sbandurski.tictactoesingle.presenter

interface IBasePresenter {
    fun onDestroy()
}